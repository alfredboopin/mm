# MEMENTO 3.1.6 — build & change notes

Round brief (user): (1) MementoSetup crashes on launch + "why is it so big?",
(2) IP Scanner rebuild whose NATURE is one-click provider targets
(Cloudflare / Vercel / Google / …) + custom lists, keeping every v2 feature,
(3) the Windows shortcut icon is wrong after install, (4) xray/sing-box
cards in Update Center have no icons — then bump the version to 3.1.6 and
ship built files + source (with and without cores) in a version-matched
download folder.

## 1 — MementoSetup 2.0.1 (was 2.0.0)

CRASH FIX: `setup-app/package.json` declared `"type": "module"` while
`tsc -p tsconfig.json` compiles the main process to **CommonJS**. Electron
then loaded `dist-electron/main.js` as an ES module and died at import with
exactly the reported error:

    ReferenceError: exports is not defined in ES module scope
    …\package.json' contains "type": "module"

The field is removed (default = CommonJS); `scripts/taskG-smoke.mjs` G1 now
loads the compiled main under an electron stub and gates on the absence of
that ReferenceError.

SIZE FIX (255.6 MB → ~133 MB): the 2.0.0 payload was the ENTIRE win-unpacked
tree (373 MB) — it carried a SECOND copy of the Electron runtime
(MEMENTO.exe alone was 235 MB) even though the installer itself IS the same
Electron runtime. 3.1.6 introduces **runtime-reuse**:

- `scripts/sync-payload.js` now ships a LITE payload (23 files, ~137 MB):
  `resources/app.asar` + tray icons + the cores (xray / sing-box / aether /
  wintun / geoip / geosite).
- At install time `installerCore.runInstall` (mode from
  `payload-meta.json`) clones the wizard's OWN runtime — the running exe is
  copied as MEMENTO.exe, then dlls / paks / locales / LICENSE /
  resources/elevate.exe ride along — and drops the payload on top.
  The wizard's own app.asar is explicitly NOT copied.
- Full uninstall contract unchanged: HKCU ARP entry, desktop + Start Menu
  shortcuts (incl. Uninstall MEMENTO), userData NEVER touched, staged
  backup restored on any failure.
- Space meters in the wizard now show payload + runtime (true footprint).
- Gates: taskG G2 (full runtime-reuse pipeline on fixtures: exe clone,
  runtime files, payload, ARP size = payload+runtime+exe, shortcuts,
  cancel, backup, userData) and G3 (full-tree regression for --stub
  fixtures).

Additional fixes found by the gates while wiring this: the runtime-reuse
branch now `mkdirSync`s the destination before the exe copy (fresh-install
ENOENT), and the ARP `EstimatedSizeKB` now includes the cloned exe
(previously payload-only → understated "Add/Remove Programs" size).

## 2 — IP Scanner v3 (provider presets)

- NEW `src/utils/scanPresets.ts`: 11 curated provider target groups with
  their published CIDR blocks — Cloudflare (58,338 hosts), Google (41,448),
  Vercel (5,624), AWS CloudFront (40,940), Microsoft Azure (32,752),
  Oracle Cloud (32,752), DigitalOcean (57,316), Hetzner (36,846),
  GitHub (10,232), ArvanCloud (34,810), Public DNS anycast (3,054).
- `ScannerTab.tsx` rebuilt (v3): provider chip grid (multi-select, exact
  host counts, checkmarks), one-click toggling adds/removes the provider's
  blocks in the target textarea (the textarea stays the single source of
  truth — trim anything), live target-total badge against the engine cap
  (≈ N / 65,536, red + blocked Start when over), Clear button, radar pulse
  while scanning, horizontally scrollable results.
- NOTHING from v2 was removed: live stat strip, LAN one-click, list import,
  port preset chips + custom ports, concurrency/timeout/reverse-DNS/geo
  tuning, per-host streaming rows, auto tags, category chips with counts,
  text filter, 4-way sort, per-row copy, copy IPs/rows/selected, CSV export.
- Gates: G4 expands every preset through the REAL engine parser
  (`expandTargets` — no errors, no overlaps, all inside the cap, Cloudflare
  exactly 58,338) and G5 runs a LIVE loopback scan incl. per-host streaming
  + cancel.

## 3 — Windows icon (the real one, everywhere)

Root cause: both electron-builder configs set `signAndEditExecutable:
false` (no signing cert exists for this project; classic exe-resource
editing needs wine), so MEMENTO.exe kept Electron's default icon — and
Windows derives shortcut icons FROM THE EXE RESOURCES, so every installed
shortcut was wrong. icon.ico riding as an extraResource cannot fix that.

Fix (no wine): `signExecutable: false` (electron-builder then applies icon
+ version resources natively, wine-free) and a verification gate
`scripts/check-icon.mjs` that byte-matches every .ico image inside each
exe. Embedded in all three artifacts:

- `MEMENTO-3.1.6.exe` (portable SFX — 6/6 icon images PASS)
- `MementoSetup-2.0.1.exe` (SFX — PASS; its exe is what becomes
  MEMENTO.exe in the runtime-reuse install, so the installed app + both
  shortcuts finally show the MEMENTO eye)
- `win-unpacked/MEMENTO.exe` (PASS)

`scripts/embed-icon.mjs` (pure-JS resedit + pe-library, overlay-preserving)
remains available as a post-build patcher for arbitrary exes.

## 4 — Update Center icon fix

`UpdateCenterTab.tsx` assigned the component to a lowercase `icon` variable
and rendered `<icon />` — JSX compiled that to a literal unknown DOM
element, so the Xray/sing-box cards showed EMPTY icon tiles (MEMENTO and
Aether were fine because their icons were referenced directly). Now
`const Icon = e.core === "xray" ? Cpu : Orbit;` + `<Icon />`. G9 gates it.

## 5 — Version 3.1.6

electron-app 3.1.6 · setup-app 2.0.1 · root 3.1.6 · UC fallback string ·
payload-meta appVersion. Pinned cores unchanged and now REAL:
xray v25.1.1, sing-box 1.14.0, aether 1.9.0 (sha256-pinned), wintun 0.14.1.

## Build receipts (this sandbox)

- Real cores fetched by `electron-app/scripts/fetch-cores.mjs` (official
  GitHub release assets; aether verified against its pinned sha256).
- `MEMENTO-3.1.6.exe` — electron-builder portable (mx=9 OOMs the 4 GB
  sandbox, `ELECTRON_BUILDER_COMPRESSION_LEVEL=7` builds clean), ~131 MB,
  WITH cores + en-US-only Chromium locales.
- `MementoSetup-2.0.1.exe` — ~133 MB (was 255.6 MB), lite payload +
  runtime-reuse, icon embedded.
- `scripts/taskG-smoke.mjs`: 69/69 PASS. `scripts/taskF-smoke.mjs`
  (regression): 91/91 PASS. Both SFX archives 7za-tested clean.
- Browser-verified via agent-browser: provider presets (counts + toggles +
  cap badge), live mock scan streaming, results table, Update Center icons
  + Check all → "Up to date", setup wizard steps + finish. Screenshots in
  `download/verify-*.png`.
