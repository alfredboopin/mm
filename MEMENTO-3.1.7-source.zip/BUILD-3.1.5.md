# MEMENTO 3.1.5 — build instructions (source WITHOUT cores)

The renderer + electron main compile from this tree. Core binaries
(xray.exe / sing-box.exe / aether.exe / wintun.dll) are NOT included in
this archive — use `MEMENTO-3.1.5-source-full.zip` for the complete
offline tree, or let MEMENTO download xray on first connect.

## taskF round — what changed in the build story

  - MementoSetup is NO LONGER an NSIS build. The old NSIS target is
    retired; the installer is now `setup-app/` — the design-exact
    MEMENTO Setup wizard (setup v2.0.0) with a real install pipeline
    (destination choice, per-user copy, Add/Remove Programs entry,
    full uninstaller preserving userData, run-after-finish).
  - The uninstaller lives INSIDE MEMENTO (`--memento-uninstall`,
    headless) and is registered by the wizard.

## Build (Windows, Node.js >= 20)

    cd memento-src/electron-app
    npm install
    npm run dist                # -> release/MEMENTO-3.1.5.exe (portable)

    cd ../setup-app
    npm install
    npm run dist                # -> release/MementoSetup-2.0.0.exe
    # (pre-dist syncs electron-app/release/win-unpacked into payload/)

## Build (Linux cross-compile, as used for the delivered binaries)

    cd memento-src/electron-app
    npm install
    npm run build
    npx electron-builder --win --x64   (signAndEditExecutable=false is set)

    cd ../setup-app
    npm install
    npm run build
    npx electron-builder --win --x64   # needs the win-unpacked payload

## Gates

    node scripts/taskF-smoke.mjs
    # 91 assertions: build gates (BOTH apps), the installer pipeline
    # (copy/ARP/shortcuts/rollback/cancel/upgrade + uninstaller contract),
    # the scanner engine (live loopback sweep), the Update Center
    # (LIVE GitHub check + full download->verify->apply of the real
    # Xray binary), structural pins.
