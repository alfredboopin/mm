import fs from "node:fs";
import esbuild from "esbuild";
const src = fs.readFileSync("src/components/ConfigBuilderTab.tsx", "utf8");
const typeStart = src.indexOf("interface BuilderForm");
const typeEnd = src.indexOf("}", src.indexOf("spiderX: string;")) + 1;
const freshStart = src.indexOf("const freshForm");
const freshEnd = src.indexOf("});", freshStart) + 3;
const genStart = src.indexOf("/* =============================================================== helpers */");
const genEnd = src.indexOf("/* ========================================================= small widgets */");
const code = src.slice(typeStart, typeEnd) + "\n" + src.slice(freshStart, freshEnd) + "\n" + src.slice(genStart, genEnd);
const js = esbuild.transformSync(code, { loader: "ts" }).code;
const mod = new Function(js + "; return { buildLink, buildJson, freshForm, genUuid, genPassword };")();
const assert = (await import("node:assert")).strict;
const f0 = mod.freshForm();

// ---- VMess ----
const vm = mod.buildLink({ ...f0, proto:"vmess", address:"example.com", port:443, uuid: mod.genUuid(), remarks:"سرور من", network:"ws", wsPath:"/ray", wsHost:"cdn.example.com", tls:true, sni:"example.com", alpn:["h2","http/1.1"], fp:"chrome" }, 443, "tls");
assert.ok(vm.link.startsWith("vmess://"), "vmess scheme");
const vmJson = JSON.parse(Buffer.from(vm.link.slice(8), "base64").toString("utf8"));
assert.equal(vmJson.v, "2"); assert.equal(vmJson.ps, "سرور من"); assert.equal(vmJson.add, "example.com");
assert.equal(vmJson.port, "443"); assert.equal(vmJson.net, "ws"); assert.equal(vmJson.host, "cdn.example.com");
assert.equal(vmJson.path, "/ray"); assert.equal(vmJson.tls, "tls"); assert.equal(vmJson.alpn, "h2,http/1.1");
assert.equal(vmJson.scy, "auto"); assert.equal(vmJson.aid, "0");
console.log("VMess OK  ->", vm.link.slice(0, 52) + "…");

// ---- VLESS + Reality ----
const vl = mod.buildLink({ ...f0, proto:"vless", address:"5.6.7.8", port:8443, uuid: mod.genUuid(), flow:"xtls-rprx-vision", reality:true, pbk:"jkkI1LgkExampleKeyThatIsLongEnough1234", sid:"01ab", spiderX:"/", sni:"www.microsoft.com", fp:"chrome", network:"tcp" }, 8443, "reality");
const vlUrl = new URL(vl.link);
assert.ok(vl.link.startsWith("vless://"));
assert.equal(vlUrl.searchParams.get("security"), "reality");
assert.equal(vlUrl.searchParams.get("pbk"), "jkkI1LgkExampleKeyThatIsLongEnough1234");
assert.equal(vlUrl.searchParams.get("sid"), "01ab");
assert.equal(vlUrl.searchParams.get("flow"), "xtls-rprx-vision");
assert.equal(vlUrl.searchParams.get("encryption"), "none");
assert.equal(vlUrl.hostname, "5.6.7.8"); assert.equal(vlUrl.port, "8443");
console.log("VLESS OK  ->", vl.link.slice(0, 52) + "…");

// ---- Trojan (Persian remarks + grpc + special password) ----
const tr = mod.buildLink({ ...f0, proto:"trojan", address:"trojan.example.ir", port:443, password:"p@ss w/örd", remarks:"تروجان ۱", network:"grpc", grpcService:"GunService", tls:true, sni:"trojan.example.ir" }, 443, "tls");
const trUrl = new URL(tr.link);
assert.ok(tr.link.startsWith("trojan://"));
assert.equal(decodeURIComponent(trUrl.username), "p@ss w/örd");
assert.equal(trUrl.searchParams.get("security"), "tls");
assert.equal(trUrl.searchParams.get("serviceName"), "GunService");
assert.equal(decodeURIComponent(trUrl.hash.slice(1)), "تروجان ۱");
console.log("Trojan OK ->", tr.link.slice(0, 52) + "…");

// ---- SS: SIP002 websafe-b64 userinfo, bracketed IPv6, obfs plugin ----
const ss = mod.buildLink({ ...f0, proto:"ss", address:"2001:db8::1", port:8388, method:"chacha20-ietf-poly1305", password:"secret-key-42", ssPlugin:"obfs-local", ssObfsMode:"http", ssPluginHost:"cdn.example.com", remarks:"ایران" }, 8388, "none");
assert.ok(ss.link.startsWith("ss://"));
const m = ss.link.match(/^ss:\/\/([^@]+)@\[([^\]]+)\]:(\d+)(\?[^#]*)?(#.*)?$/);
assert.ok(m, "ss structure with bracketed IPv6");
assert.equal(Buffer.from(m[1].replace(/-/g,"+").replace(/_/g,"/"), "base64").toString("utf8"), "chacha20-ietf-poly1305:secret-key-42");
const q = new URLSearchParams(m[4].slice(1));
assert.equal(q.get("plugin"), "obfs-local;obfs=http;obfs-host=cdn.example.com");
assert.equal(decodeURIComponent(m[5].slice(1)), "ایران");
console.log("SS OK     ->", ss.link.slice(0, 62) + "…");

// ---- SS 2022 random key + UUID v4 shape ----
assert.equal(Buffer.from(mod.genPassword("2022-blake3-aes-256-gcm"), "base64").length, 32, "2022 key = 32 bytes");
assert.equal(Buffer.from(mod.genPassword("2022-blake3-aes-128-gcm"), "base64").length, 16, "128 key = 16 bytes");
assert.match(mod.genUuid(), /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
console.log("Randoms OK (uuid v4 + ss2022 keys)");

// ---- JSON previews ----
assert.ok(vm.json.includes('"protocol": "vmess"') && vm.json.includes('"tlsSettings"'));
assert.ok(vl.json.includes('"realitySettings"') && vl.json.includes('"shortId": "01ab"'));
assert.ok(tr.json.includes('"trojan"') && tr.json.includes('"grpcSettings"'));
assert.ok(ss.json.includes('"shadowsocks"') && ss.json.includes('"plugin": "obfs-local"'));
console.log("JSON previews OK");
console.log("\nALL LINK-GENERATION CHECKS PASSED");
