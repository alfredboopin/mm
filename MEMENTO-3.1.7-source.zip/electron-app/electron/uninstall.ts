/**
 * MEMENTO — the complete uninstaller (--memento-uninstall).
 *
 * Registered in Add/Remove Programs by MementoSetup as
 *   "C:\…\MEMENTO.exe" --memento-uninstall
 *
 * CONTRACT (the installer's Notes step promises this — keep it true):
 *   REMOVED   program files (the install dir), desktop + Start Menu
 *             shortcuts, the ARP registration, any running core child.
 *   KEPT      userData (%APPDATA%\com.epodonios.memento) — profiles,
 *             subscriptions, routing rules, logs, downloaded cores. A
 *             reinstall picks up exactly where the user left off. A full
 *             purge stays available from Settings → Maintenance.
 *
 * Headless mode: no window, no tray, no single-instance lock fight —
 * argv is checked BEFORE requestSingleInstanceLock in main.ts.
 * The final self-delete runs detached (`cmd /c timeout & rmdir`) because
 * Windows cannot delete a running executable's own directory.
 *
 * The plan builder is ELECTRON-FREE for the gate scripts; the runner is
 * the Electron glue (dialogs + fs + child_process).
 */
import path from "path";

export const UNINSTALL_FLAG = "--memento-uninstall";

export function isUninstallInvocation(argv: string[]): boolean {
  return argv.slice(2).includes(UNINSTALL_FLAG);
}

export function isQuietUninstall(argv: string[]): boolean {
  return argv.slice(2).includes("/quiet") || argv.slice(2).includes("--quiet");
}

export interface UninstallPlan {
  installDir: string;
  exeName: string;
  shortcuts: string[];
  registryKey: string | null;
  preservedUserData: string;
}

/** Where MementoSetup installs by default (per-user, mirrors setup-app). */
export function defaultInstallDir(isWin: boolean, home: string, localAppData?: string | null): string {
  if (isWin) {
    const lad = localAppData || path.join(home, "AppData", "Local");
    return path.join(lad, "Programs", "MEMENTO");
  }
  return path.join(home, ".local", "share", "memento-test");
}

/** Build the exact removal plan. ELECTRON-FREE. */
export function buildPlan(args: {
  isWin: boolean;
  exePath: string;
  desktopDir: string;
  startMenuDir: string;
  userDataDir: string;
}): UninstallPlan {
  const { isWin, exePath, desktopDir, startMenuDir, userDataDir } = args;
  const installDir = path.dirname(exePath);
  const exeName = path.basename(exePath);
  return {
    installDir,
    exeName,
    shortcuts: isWin
      ? [
          path.join(desktopDir, "MEMENTO.lnk"),
          path.join(startMenuDir, "MEMENTO.lnk"),
          path.join(startMenuDir, "Uninstall MEMENTO.lnk"),
        ]
      : [
          path.join(desktopDir, "memento.desktop"),
          path.join(startMenuDir, "memento.desktop"),
          path.join(startMenuDir, "memento-uninstall.desktop"),
        ],
    registryKey: isWin
      ? "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MEMENTO"
      : null,
    preservedUserData: userDataDir,
  };
}

/** The detached self-delete command (POSIX test twin included). */
export function selfDeleteCommand(installDir: string, isWin: boolean): { cmd: string; args: string[] } {
  if (isWin) {
    return {
      cmd: "cmd",
      args: ["/c", `timeout /t 2 /nobreak >nul & rmdir /s /q "${installDir}"`],
    };
  }
  return { cmd: "sh", args: ["-c", `sleep 1; rm -rf '${installDir.replace(/'/g, "'\\''")}'`] };
}

/**
 * Terminate every OTHER MEMENTO.exe (a running GUI would keep the install
 * dir locked). The uninstaller itself is MEMENTO.exe too, so the own pid
 * must be excluded — naive `taskkill /IM MEMENTO.exe /F` would suicide
 * mid-uninstall. Returns the pids that were terminated.
 */
export function otherMementoPids(
  opts: { exeName: string; ownPid: number; isWin: boolean; listOutput: string }
): number[] {
  const { exeName, ownPid, isWin, listOutput } = opts;
  const pids: number[] = [];
  if (isWin) {
    // tasklist /FI "IMAGENAME eq MEMENTO.exe" /FO CSV /NH
    for (const line of String(listOutput || "").split(/\r?\n/)) {
      const m = line.match(/^"([^"]+)","(\d+)"/);
      if (m && m[1].toLowerCase() === exeName.toLowerCase()) {
        const pid = Number(m[2]);
        if (Number.isInteger(pid) && pid > 0 && pid !== ownPid) pids.push(pid);
      }
    }
  } else {
    // ps -eo comm=,pid=
    for (const line of String(listOutput || "").split(/\r?\n/)) {
      const m = line.match(/^(.+?)\s+(\d+)$/);
      if (m && m[1].trim() === exeName) {
        const pid = Number(m[2]);
        if (pid !== ownPid) pids.push(pid);
      }
    }
  }
  return pids;
}

export function terminateCommand(pid: number, isWin: boolean): { cmd: string; args: string[] } {
  return isWin
    ? { cmd: "taskkill", args: ["/F", "/PID", String(pid), "/T"] }
    : { cmd: "kill", args: ["-9", String(pid)] };
}
