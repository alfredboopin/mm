# MEMENTO 3.1.7 — build notes

## The four changes of this round

1. **MementoSetup installs again + design-exact window**
   - ROOT CAUSE of the user's `Installation failed: ENOENT …\Temp\<id>\resources\payload`:
     the setup ships as an electron-builder **portable** SFX. Every launch of the
     SAME exe extracts to the SAME `%TEMP%\<unpack-id>` folder and a NEW launch
     begins with `RMDir /r` on that exact folder (portable.nsi line 38). Users
     double-click → the second stub wipes the payload + loose data files out from
     under the RUNNING wizard (running exe/DLLs survive — Windows locks open
     images — data files do not).
   - FIX (setup-app/electron/main.ts): seconds after launch the payload is
     **staged** into a private `%LOCALAPPDATA%\MementoSetup\staging\stage-<pid>-<ts>`
     folder and the install reads from THERE (`installPayloadDir()`); stale stage
     folders are cleaned on boot; the stage is disposed on quit.
   - FIX (setup-app/electron/installerCore.ts): the installer is now TOLERANT —
     vanished/locked files are skipped with honest log lines and the install
     COMPLETES; skipped payload files produce a visible warning pointing at
     Update Center; missing cores after install are reported honestly; the
     payload-missing message now explains the antivirus / double-launch cause.
   - Window: the Electron frame is now **transparent** with the 900×640 design
     canvas at exact 1:1 scale (960×730 content incl. shadow margin), fixed size —
     the rounded corners ARE the window shape; no square corners sticking out.

2. **Import Config → Config Builder (v2rayN-style generator)**
   - New `src/components/ConfigBuilderTab.tsx` behind a segmented mode in
     ImportTab (Quick Import / Config Builder). Protocols VMess / VLESS (Reality,
     Vision) / Trojan / Shadowsocks (SIP002 + plugins), transports tcp/ws/grpc/h2/
     httpupgrade, TLS block (sni/alpn/fp/allowInsecure), step rail with auto
     checks, live terminal link preview + JSON view + inline QR (qrcode dep),
     UUID/password generators, validation-gated Add-to-MEMENTO through the real
     `addConfigs()` path. Fully bilingual (EN/FA) + RTL.

3. **MHRV (GOOGLE SIDE) overhaul — mirrors mhrv-rs v1.9.37**
   - Front-domain MANAGER (selectable chip list + add/remove, active chip =
     frontDomain), SNI pool chip with probe, **multi Deployment IDs** textarea
     (one per line) with real round-robin auto-failover (`relayWithFailover`),
     Auth key with show toggle, Mode select (Apps Script (MTM) / Direct),
     Google IP + scan IPs, Share-with-other-devices (binds 0.0.0.0), HTTP/SOCKS
     ports, Advanced: Upstream SOCKS5 (real SOCKS5 client chaining), Parallel
     dispatch, Log level, Verify TLS, Normalize X/Twitter GraphQL, YouTube through
     relay, Block QUIC (UDP/443), Block STUN/TURN; Save config (config path
   shown), Install/Remove/Check CA, Check for updates, and a Recent log console
     (500-line ring buffer, level filter, show/save/clear) — new IPC:
     mhrv_logs_get/clear/save, mhrv_ca_remove/check, mhrv_update_check.

4. **Live Connection = per-app consumption**
   - sing-box clash_api rows now carry `metadata.sourceIP/sourcePort`
     (connectionStats.ts) and LiveConnTab joins them to the OS socket snapshot
     (netstat/tasklist) → per-app byte ledger with reset-safe deltas, EMA live
     speeds, session totals, usage share bars, top-consumer highlight, per-app
     drill-down (sockets + proxied connections + remote targets). xray is shown
     honestly at tunnel level (its stats API has no per-connection counters).

## Version bump
- root + electron-app: **3.1.7** · setup-app: **2.0.2** · Update Center fallback: 3.1.7

## Build pipeline (Windows x64, cross-built on Linux)
```
cd electron-app  && ELECTRON_BUILDER_COMPRESSION_LEVEL=7 npm run dist     # MEMENTO-3.1.7.exe
cd setup-app     && ELECTRON_BUILDER_COMPRESSION_LEVEL=7 npm run dist     # MementoSetup-2.0.2.exe (predist runs sync-payload)
```
- `ELECTRON_BUILDER_COMPRESSION_LEVEL=7` is REQUIRED (the default mx=9 7z pass
  OOMs a 4 GB sandbox).
- Icons are embedded natively by electron-builder (`signExecutable: false`,
  no wine); verify with `node scripts/check-icon.mjs <exe> <icon.ico>`.
- Gates: `scripts/taskH-smoke.mjs` (77), `scripts/taskG-smoke.mjs` (69),
  `scripts/taskF-smoke.mjs` (91) — all green on the shipped artifacts.
- Deliver: `node scripts/taskH-zip.mjs` → `download/MEMENTO-3.1.7/`.
