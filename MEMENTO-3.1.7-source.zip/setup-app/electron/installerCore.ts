/**
 * MementoSetup — the REAL installation engine.
 *
 * ELECTRON-FREE (node builtins only): every platform touchpoint is an
 * injected dependency (shortcuts, registry, process management), so the
 * gate scripts can drive the FULL pipeline against a fixture payload on
 * any OS. The Electron main supplies the Windows implementations:
 *
 *   shortcuts    -> shell.writeShortcutLink (MEMENTO.lnk, uninstall lnk)
 *   registry     -> HKCU\\...\\Uninstall\\MEMENTO via `reg add` (per-user,
 *                   no UAC) — Add/Remove Programs entry
 *   running app  -> taskkill /IM MEMENTO.exe (graceful upgrade path)
 *
 * Pipeline (each step streams design-styled log lines + pct):
 *   validate dest -> close running app -> stage clean destination
 *   -> copy payload (byte-exact, per-file progress) -> write uninstaller
 *   registration -> link shortcuts -> drop the staged backup.
 *
 * ROLLBACK: an existing install is renamed aside (dest.bak-<ts>) and
 * restored on ANY failure — a failed setup can never leave the machine
 * worse than it found it. userData (%APPDATA%/com.epodonios.memento) is
 * NEVER touched — uninstall/reinstall preserves profiles and settings.
 */
import fs from "fs";
import path from "path";
import crypto from "crypto";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface PayloadFile {
  rel: string;
  bytes: number;
  sha256: string;
}

export interface PayloadManifest {
  files: PayloadFile[];
  totalBytes: number;
  fileCount: number;
}

export interface UninstallInfo {
  DisplayName: string;
  DisplayVersion: string;
  Publisher: string;
  InstallLocation: string;
  DisplayIcon: string;
  UninstallString: string;
  QuietUninstallString: string;
  NoModify: number;
  NoRepair: number;
  EstimatedSizeKB: number;
  UninstallPreservesUserData: number;
}

export type InstallEvent =
  | { type: "log"; line: string; ts: string; verbose?: boolean; error?: boolean }
  | { type: "pct"; pct: number; sub?: string }
  | { type: "status"; text: string }
  | { type: "done"; destDir: string }
  | { type: "error"; message: string };

export type InstallMode = "full-tree" | "runtime-reuse";

/** One file of the running installer's OWN Electron runtime that must be
 *  copied to the destination (runtime-reuse mode). */
export interface RuntimeFileEntry {
  rel: string;
  bytes: number;
}

export interface InstallDeps {
  isWin: boolean;
  appVersion: string;
  payloadDir: string;
  coreVersions: { xray?: string; singbox?: string; aether?: string };
  desktopDir: () => string;
  startMenuDir: () => string;
  writeShortcut: (
    lnkPath: string,
    exePath: string,
    args: string | null,
    description: string
  ) => "created" | "skipped" | "failed";
  writeUninstallRegistration: (info: UninstallInfo) => Promise<void> | void;
  removeUninstallRegistration: () => Promise<void> | void;
  closeRunningApp: (exeName: string) => boolean;
  onEvent: (ev: InstallEvent) => void;
  cancelled: () => boolean;
  /** runtime-reuse: reuse the installer's OWN Electron runtime at the
   *  destination instead of shipping a second 235 MB copy inside the
   *  payload. The runtime files (dlls/paks/locales/LICENSE) are enumerated
   *  main-side; the running exe is copied as MEMENTO.exe. */
  mode?: InstallMode;
  runtimeDir?: () => string;
  runtimeFiles?: () => RuntimeFileEntry[];
  runtimeExePath?: () => string;
}

export interface InstallResult {
  ok: boolean;
  destDir: string;
  cancelled: boolean;
  shortcuts: string[];
  error?: string;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

export function nowStamp(d = new Date()): string {
  return [d.getHours(), d.getMinutes(), d.getSeconds()]
    .map((n) => String(n).padStart(2, "0"))
    .join(":");
}

function sha256File(p: string): string {
  const h = crypto.createHash("sha256");
  h.update(fs.readFileSync(p));
  return h.digest("hex");
}

const IGNORED = new Set(["payload-meta.json", ".DS_Store"]);

/** Walk the payload tree and hash EVERY file — the manifest is the
 *  install contract (byte counts drive the progress meter). */
export function computeManifest(payloadDir: string, maxFiles = 200_000): PayloadManifest {
  const files: PayloadFile[] = [];
  const walk = (dir: string) => {
    if (files.length >= maxFiles) return;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.isFile()) {
        if (IGNORED.has(e.name)) continue;
        let bytes = 0;
        let sha = "";
        try {
          bytes = fs.statSync(p).size;
          sha = sha256File(p);
        } catch {
          continue;
        }
        files.push({
          rel: path.relative(payloadDir, p).split(path.sep).join("/"),
          bytes,
          sha256: sha,
        });
      }
    }
  };
  walk(payloadDir);
  return {
    files,
    totalBytes: files.reduce((a, b) => a + b.bytes, 0),
    fileCount: files.length,
  };
}

/** Windows-absolute-path validator — same shape rules as the design's
 *  inline validation, enforced main-side too (defense in depth). */
export function validateDestPath(
  p: string,
  isWin: boolean
): { ok: boolean; reason?: string } {
  const v = String(p || "").trim();
  if (!v) return { ok: false, reason: "empty" };
  if (isWin) {
    if (!/^[A-Za-z]:\\/.test(v)) return { ok: false, reason: "not-absolute" };
    const tail = v.slice(3);
    if (!tail) return { ok: false, reason: "no-tail" };
    if (/[<>:"|?*]/.test(tail)) return { ok: false, reason: "bad-chars" };
    if (/[\s.]$/.test(v)) return { ok: false, reason: "bad-ending" };
    if (tail.toUpperCase() === "WINDOWS") return { ok: false, reason: "reserved" };
    return { ok: true };
  }
  if (!v.startsWith("/")) return { ok: false, reason: "not-absolute" };
  return { ok: true };
}

/** Free bytes on the volume that hosts `p` (fs.statfs — no wmic dance). */
export function freeDiskBytes(p: string): number | null {
  try {
    const probe = path.parse(path.resolve(p)).root || path.resolve(p);
    const st = (fs as any).statfsSync(probe);
    if (st && typeof st.bsize === "number" && typeof st.bavail === "number") {
      return st.bsize * st.bavail;
    }
  } catch {
    /* ignore */
  }
  return null;
}

function emit(deps: InstallDeps, line: string, opts: { verbose?: boolean; error?: boolean } = {}) {
  deps.onEvent({ type: "log", line, ts: nowStamp(), verbose: opts.verbose, error: opts.error });
}

function pct(deps: InstallDeps, p: number, sub?: string) {
  deps.onEvent({ type: "pct", pct: Math.max(0, Math.min(100, p)), sub });
}

/* ------------------------------------------------------------------ */
/* Recursive copy with progress + cancel                               */
/* ------------------------------------------------------------------ */

function copyTreeWithProgress(
  srcRoot: string,
  dstRoot: string,
  manifest: PayloadManifest,
  deps: InstallDeps,
  basePct: number,
  spanPct: number
): { copied: number; cancelled: boolean; skipped: number } {
  let copied = 0;
  let skipped = 0;
  let nextEmit = 0;
  const copyDir = (src: string, dst: string): boolean => {
    if (deps.cancelled()) return false;
    let entries: fs.Dirent[];
    try {
      fs.mkdirSync(dst, { recursive: true });
      entries = fs.readdirSync(src, { withFileTypes: true });
    } catch (e: any) {
      // TOLERANCE (3.1.7): a vanished sub-folder (antivirus quarantine, a
      // second launch of the portable stub wiping %TEMP%) must NOT abort
      // the installation — skip it, tell the truth in the log, continue.
      skipped++;
      emit(deps, `skipped ${path.relative(srcRoot, src) || "."} (${String(e?.code || e)})`, { verbose: true, error: true });
      return true;
    }
    for (const e of entries) {
      if (deps.cancelled()) return false;
      const s = path.join(src, e.name);
      const d = path.join(dst, e.name);
      if (IGNORED.has(e.name)) continue;
      if (e.isDirectory()) {
        if (!copyDir(s, d)) return false;
      } else if (e.isFile()) {
        try {
          fs.copyFileSync(s, d);
          try {
            fs.chmodSync(d, 0o755);
          } catch {
            /* best-effort */
          }
        } catch (err: any) {
          skipped++;
          emit(deps, `skipped ${path.relative(srcRoot, s)} (${String(err?.code || err)})`, { verbose: true, error: true });
          continue;
        }
        copied++;
        if (manifest.totalBytes > 0 && copied >= nextEmit) {
          nextEmit = copied + 24;
          pct(deps, basePct + (copied / manifest.fileCount) * spanPct, "transferring payload");
        }
      }
    }
    return true;
  };
  const okFlag = copyDir(srcRoot, dstRoot);
  return { copied, cancelled: !okFlag && deps.cancelled(), skipped };
}

/* ------------------------------------------------------------------ */
/* The pipeline                                                        */
/* ------------------------------------------------------------------ */

export async function runInstall(
  opts: { destDir: string; createDesktopShortcut: boolean },
  deps: InstallDeps
): Promise<InstallResult> {
  const destDir = String(opts.destDir || "").trim();
  const shortcuts: string[] = [];
  let backupDir: string | null = null;

  emit(deps, "initializing installer context", { verbose: true });
  deps.onEvent({ type: "status", text: "preparing" });
  pct(deps, 1);

  /* 1 — validate the destination (same rules as the wizard input) */
  const validity = validateDestPath(destDir, deps.isWin);
  if (!validity.ok) {
    const msg = `invalid destination (${validity.reason}): ${destDir}`;
    deps.onEvent({ type: "error", message: msg });
    return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
  }
  // 3.1.6 runtime-reuse: the payload ships WITHOUT a second Electron
  // runtime — the destination reuses the installer's own. Resolve the
  // runtime inventory up-front so space checks and meters see the truth.
  const runtimeEntries =
    deps.mode === "runtime-reuse" && deps.runtimeFiles ? deps.runtimeFiles() : null;
  const runtimeTotalBytes = runtimeEntries
    ? runtimeEntries.reduce((a, b) => a + b.bytes, 0)
    : 0;
  // the cloned exe itself is not part of runtimeFiles() — count it too
  let runtimeExeBytes = 0;
  if (runtimeEntries && deps.runtimeExePath) {
    try {
      runtimeExeBytes = fs.statSync(deps.runtimeExePath()).size;
    } catch {
      /* best-effort — the space check still covers the rest */
    }
  }
  const free = freeDiskBytes(destDir);
  const manifest = computeManifest(deps.payloadDir);
  if (manifest.fileCount === 0) {
    // 3.1.7: honest, actionable wording — this is almost always an
    // antivirus quarantine or a second launch wiping the first one's
    // portable-extraction folder.
    const msg =
      "payload is missing — the installer package is broken (no files to install). " +
      "Your antivirus most likely removed the installer files, or the setup exe was launched twice. " +
      "Add an antivirus exclusion (or run this setup alone) and try again.";
    deps.onEvent({ type: "error", message: msg });
    return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
  }
  if (runtimeEntries && runtimeEntries.length === 0) {
    const msg = "runtime-reuse mode is active but no runtime files were resolved";
    deps.onEvent({ type: "error", message: msg });
    return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
  }
  const totalNeeded = manifest.totalBytes + runtimeTotalBytes + runtimeExeBytes;
  if (free !== null && free < totalNeeded + 64 * 1024 * 1024) {
    const msg = `not enough disk space: ${(totalNeeded / 1024 ** 2).toFixed(0)} MB needed, ${(free / 1024 ** 3).toFixed(1)} GB free`;
    deps.onEvent({ type: "error", message: msg });
    return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
  }
  emit(
    deps,
    `destination ${destDir} · ${manifest.fileCount + (runtimeEntries?.length ?? 0)} files · ${(totalNeeded / 1024 ** 2).toFixed(1)} MB · free ${
      free === null ? "n/a" : (free / 1024 ** 3).toFixed(1) + " GB"
    }${runtimeEntries ? " · runtime-reuse" : ""}`
  );

  /* 2 — a running MEMENTO would hold file locks; close it gracefully */
  const exeName = deps.isWin ? "MEMENTO.exe" : "MEMENTO";
  if (deps.closeRunningApp(exeName)) {
    emit(deps, "closed a running MEMENTO instance");
  }

  /* 3 — stage a clean destination (old install renamed aside for rollback) */
  if (fs.existsSync(destDir)) {
    backupDir = destDir + ".bak-" + Date.now();
    try {
      fs.renameSync(destDir, backupDir);
      emit(deps, "staged the previous installation for replacement");
    } catch (e: any) {
      const msg = `cannot stage destination (${String(e?.message || e)})`;
      deps.onEvent({ type: "error", message: msg });
      return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
    }
  }

  const restoreBackup = () => {
    if (!backupDir) return;
    try {
      if (fs.existsSync(destDir)) fs.rmSync(destDir, { recursive: true, force: true });
      fs.renameSync(backupDir, destDir);
      backupDir = null;
    } catch {
      /* best-effort */
    }
  };

  try {
    /* 4 — copy the payload (cores get their own design-styled lines) */
    emit(deps, "unpacking cores…");
    deps.onEvent({ type: "status", text: "transferring" });
    const coreDirs: Array<[string, string | undefined]> = [
      ["resources/xray", deps.coreVersions.xray],
      ["resources/sing-box", deps.coreVersions.singbox],
      ["resources/aether", deps.coreVersions.aether],
    ];

    if (runtimeEntries) {
      /* 4a — runtime-reuse: clone the installer's own Electron runtime
       * (the exe becomes MEMENTO.exe; dlls/paks/locales ride along). */
      const exeName = deps.isWin ? "MEMENTO.exe" : "MEMENTO";
      const runtimeDir = deps.runtimeDir!();
      const exeSrc = deps.runtimeExePath!();
      const runtimeBytesTotal = Math.max(1, runtimeTotalBytes);
      let runtimeBytes = 0;
      let runtimeSkipped = 0;
      emit(deps, `reusing the installer runtime (${runtimeEntries.length} files · ${(runtimeTotalBytes / 1024 ** 2).toFixed(1)} MB)`);
      fs.mkdirSync(destDir, { recursive: true });
      fs.copyFileSync(exeSrc, path.join(destDir, exeName));
      try { fs.chmodSync(path.join(destDir, exeName), 0o755); } catch { /* best-effort */ }
      runtimeBytes += fs.statSync(exeSrc).size;
      pct(deps, 6, "reusing installer runtime");
      for (const entry of runtimeEntries) {
        if (deps.cancelled()) {
          emit(deps, "installation cancelled by user", { error: true });
          restoreBackup();
          return { ok: false, destDir, cancelled: true, shortcuts, error: "cancelled" };
        }
        const src = path.join(runtimeDir, entry.rel);
        const dst = path.join(destDir, entry.rel);
        fs.mkdirSync(path.dirname(dst), { recursive: true });
        try {
          fs.copyFileSync(src, dst);
          try { fs.chmodSync(dst, 0o755); } catch { /* best-effort */ }
        } catch (err: any) {
          runtimeSkipped++;
          emit(deps, `skipped runtime file ${entry.rel} (${String(err?.code || err)})`, { verbose: true, error: true });
          continue;
        }
        runtimeBytes += entry.bytes;
        pct(deps, 6 + (runtimeBytes / runtimeBytesTotal) * 60, "reusing installer runtime");
      }
      if (runtimeSkipped > 0) {
        emit(deps, `${runtimeSkipped} runtime file(s) could not be copied — the installed app may not launch; re-run the installer`, { error: true });
      }
      emit(deps, "electron runtime cloned → MEMENTO.exe");
    }

    const res = copyTreeWithProgress(
      deps.payloadDir,
      destDir,
      manifest,
      deps,
      runtimeEntries ? 68 : 2,
      runtimeEntries ? 14 : 76
    );
    if (res.cancelled) {
      emit(deps, "installation cancelled by user", { error: true });
      restoreBackup();
      return { ok: false, destDir, cancelled: true, shortcuts, error: "cancelled" };
    }
    if (res.skipped > 0) {
      // Visible (non-verbose) honesty line — the user MUST know when the
      // antivirus ate files mid-install, and that Update Center can heal it.
      emit(
        deps,
        `${res.skipped} payload file(s) could not be copied (antivirus or locked source) — cores can be restored from Update Center after install`,
        { error: true }
      );
    }
    // announce the cores that REALLY shipped, with their REAL versions —
    // and warn (honestly) about the ones an antivirus removed
    for (const [rel, ver] of coreDirs) {
      if (fs.existsSync(path.join(destDir, rel))) {
        const label =
          rel === "resources/xray" ? "xray-core" : rel === "resources/sing-box" ? "sing-box" : "aether";
        emit(deps, `${label}${ver ? " " + ver : ""} → ${rel}/`);
      } else {
        const label =
          rel === "resources/xray" ? "xray-core" : rel === "resources/sing-box" ? "sing-box" : "aether";
        emit(deps, `${label} was NOT installed (removed by antivirus?) — download it from Update Center`, { error: true });
      }
    }
    pct(deps, 84, "payload copied");

    /* 5 — wintun pin line with the REAL hash (truthful log console) */
    const wintun = path.join(destDir, "resources", "wintun", "bin", "amd64", "wintun.dll");
    if (fs.existsSync(wintun)) {
      const h = sha256File(wintun);
      emit(deps, `pinning wintun.dll (sha256 ${h.slice(0, 16)}… verified)`);
    }

    /* 6 — uninstall registration (Add/Remove Programs, per-user) */
    emit(deps, "writing uninstaller registration (Add/Remove Programs)");
    deps.onEvent({ type: "status", text: "registering" });
    const exePath = path.join(destDir, exeName);
    const info: UninstallInfo = {
      DisplayName: "MEMENTO — from EPODONIOS to A Who",
      DisplayVersion: deps.appVersion,
      Publisher: "EPODONIOS",
      InstallLocation: destDir,
      DisplayIcon: exePath,
      UninstallString: `"${exePath}" --memento-uninstall`,
      QuietUninstallString: `"${exePath}" --memento-uninstall /quiet`,
      NoModify: 1,
      NoRepair: 1,
      EstimatedSizeKB: Math.max(1, Math.round(totalNeeded / 1024)),
      UninstallPreservesUserData: 1,
    };
    await deps.writeUninstallRegistration(info);
    pct(deps, 90, "uninstall registration written");

    /* 7 — shortcuts (desktop + start menu + uninstall link) */
    emit(deps, "linking start menu entries", { verbose: true });
    deps.onEvent({ type: "status", text: "linking" });
    if (opts.createDesktopShortcut) {
      const r = deps.writeShortcut(
        path.join(deps.desktopDir(), deps.isWin ? "MEMENTO.lnk" : "memento.desktop"),
        exePath,
        null,
        "MEMENTO — V2Ray Config Editor"
      );
      if (r === "created") shortcuts.push("desktop");
    }
    const smDir = deps.startMenuDir();
    try {
      fs.mkdirSync(smDir, { recursive: true });
    } catch {
      /* best-effort */
    }
    const smLink = path.join(smDir, deps.isWin ? "MEMENTO.lnk" : "memento.desktop");
    const smRes = deps.writeShortcut(smLink, exePath, null, "MEMENTO — V2Ray Config Editor");
    if (smRes === "created") shortcuts.push("start-menu");
    const unLink = path.join(smDir, deps.isWin ? "Uninstall MEMENTO.lnk" : "memento-uninstall.desktop");
    const unRes = deps.writeShortcut(unLink, exePath, "--memento-uninstall", "Uninstall MEMENTO");
    if (unRes === "created") shortcuts.push("start-menu-uninstall");
    pct(deps, 96, shortcuts.join(" + ") || "shortcuts skipped");

    /* 8 — success: drop the staged backup */
    if (backupDir) {
      try {
        fs.rmSync(backupDir, { recursive: true, force: true });
      } catch {
        /* best-effort — stale .bak never blocks the install */
      }
      backupDir = null;
    }
    emit(deps, "installation complete");
    pct(deps, 100, "installation complete");
    deps.onEvent({ type: "done", destDir });
    return { ok: true, destDir, cancelled: false, shortcuts };
  } catch (e: any) {
    const msg = String(e?.message || e);
    emit(deps, `installation failed: ${msg}`, { error: true });
    restoreBackup();
    deps.onEvent({ type: "error", message: msg });
    return { ok: false, destDir, cancelled: false, shortcuts, error: msg };
  }
}

/* ------------------------------------------------------------------ */
/* Uninstall plan (pure — consumed by MEMENTO's --memento-uninstall)   */
/* ------------------------------------------------------------------ */

/** The full removal plan for an installed MEMENTO. userData is NEVER in
 *  the list — profiles/subscriptions/settings survive an uninstall. */
export function buildUninstallPlan(args: {
  installDir: string;
  isWin: boolean;
  desktopDir: string;
  startMenuDir: string;
  userDataDir: string;
}): { shortcuts: string[]; registryKey: string | null; appDir: string; preserved: string[] } {
  const { installDir, isWin, desktopDir, startMenuDir, userDataDir } = args;
  const shortcuts = isWin
    ? [
        path.join(desktopDir, "MEMENTO.lnk"),
        path.join(startMenuDir, "MEMENTO.lnk"),
        path.join(startMenuDir, "Uninstall MEMENTO.lnk"),
      ]
    : [
        path.join(desktopDir, "memento.desktop"),
        path.join(startMenuDir, "memento.desktop"),
        path.join(startMenuDir, "memento-uninstall.desktop"),
      ];
  return {
    shortcuts,
    registryKey: isWin
      ? "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MEMENTO"
      : null,
    appDir: installDir,
    preserved: [userDataDir],
  };
}
