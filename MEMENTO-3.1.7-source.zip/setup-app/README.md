# MementoSetup (setup-app)

The design-exact MEMENTO Setup wizard — the provided HTML design
(colors, layout, animations, EN/FA i18n) reproduced verbatim as the
installer's real interface, with the demo simulation replaced by a REAL
installation pipeline.

## What the wizard really does

| Step (design) | Real behavior |
| --- | --- |
| Welcome | Live context: payload size, real core versions, real free space |
| Notes | — |
| Destination | Real default `%LOCALAPPDATA%\Programs\MEMENTO`, native directory picker, per-keystroke validation + live free-space meters |
| Installing | validate dest → taskkill a running MEMENTO → stage old install as `.bak-<ts>` → copy payload with per-file progress → REAL wintun sha256 line → HKCU `Uninstall\MEMENTO` registration (Add/Remove Programs) → desktop + Start Menu + "Uninstall MEMENTO" shortcuts |
| Finish | REAL launch: spawns `MEMENTO.exe` detached and quits |

Every failure rolls the previous install back; userData
(`%APPDATA%\com.epodonios.memento`) is never touched.

## Uninstaller

The Add/Remove Programs entry points at:

    "C:\...\MEMENTO.exe" --memento-uninstall

A complete uninstaller inside MEMENTO itself (electron-app/electron/
uninstall.ts + the headless mode in main.ts): kills the cores, kills
every OTHER MEMENTO.exe (own-pid aware), removes the three shortcuts,
deletes the ARP key, then self-deletes the install dir detached —
PRESERVING userData exactly as the wizard's Notes step promises.

## Build (Windows, Node >= 20)

    cd memento-src/electron-app   && npm install && npm run dist      # portable app
    cd ../setup-app               && npm install && npm run dist      # the installer

`setup-app`'s `pre-dist` hook runs `scripts/sync-payload.js`, which
copies `electron-app/release/win-unpacked` into `setup-app/payload`
(the tree the wizard copies onto the user's disk). Artifacts:

    electron-app/release/MEMENTO-<version>.exe       — portable app
    setup-app/release/MementoSetup-<version>.exe     — the installer

## Tests

The pipeline is ELECTRON-FREE (`installerCore.ts`) with injected platform
deps — `scripts/taskF-smoke.mjs` drives the FULL pipeline (copy, ARP
fields, shortcuts, cancel/failure rollback, upgrade path) on any OS.
