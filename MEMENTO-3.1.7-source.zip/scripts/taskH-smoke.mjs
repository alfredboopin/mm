/**
 * taskH-smoke.mjs — the 3.1.7 feature gates.
 *
 * Covers the four user changes of the 3.1.7 round:
 *   H1  MementoSetup window = design-exact 900×640 canvas, TRANSPARENT
 *       frame (rounded corners are the real window shape, no square
 *       corners sticking out)
 *   H2  Payload STAGING rescue — the root cause of the user's
 *       "Installation failed: ENOENT …\Temp\<id>\resources\payload":
 *       a second launch of the portable exe RMDir's the shared
 *       %TEMP%\<unpack-id> extraction folder (electron-builder
 *       portable.nsi line 38) and wipes the payload from under the
 *       RUNNING wizard. The wizard now stages the payload into a
 *       private %LOCALAPPDATA% folder seconds after launch and installs
 *       from there.
 *   H3  Tolerant installerCore — vanished/locked files are SKIPPED with
 *       honest log lines, the install COMPLETES (live behavioral test
 *       with an unreadable file), improved payload-missing wording.
 *   H4  MHRV overhaul — front-domain manager, multi Deployment IDs with
 *       round-robin auto-failover, the full mhrv-rs settings surface
 *       (shareLan, upstream SOCKS5, parallel dispatch, log level, X/Twitter
 *       normalization, YouTube relay, QUIC/STUN blocks), log ring buffer,
 *       CA remove/check, update check.
 *   H5  Live Connection per-app consumption — sing-box sourcePort
 *       attribution, per-app byte ledger + EMA speeds, custom redesign.
 *   H6  Config Builder (v2rayN-style generator) inside Import Config.
 *   H7  Real Windows artifacts exist for 3.1.7 / 2.0.2.
 *
 * Run: node scripts/taskH-smoke.mjs
 */
import fs from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import { spawnSync } from "child_process";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const SETUP = path.join(ROOT, "setup-app");
const APP = path.join(ROOT, "electron-app");

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = "") => {
  if (cond) { pass++; console.log(`  PASS  ${name}`); }
  else { fail++; console.log(`  FAIL  ${name}${detail ? " — " + String(detail).slice(0, 240) : ""}`); }
};

/* ================= H1 — design-exact transparent window ================= */
console.log("\nH1 — setup window: 900×640 design, transparent frame, no square corners");
{
  const mainJs = fs.readFileSync(path.join(SETUP, "dist-electron", "main.js"), "utf8");
  ok("H1 window content size is 960×730 (900×640 canvas at 1:1 + shadow margin)",
    /width:\s*960/.test(mainJs) && /height:\s*730/.test(mainJs));
  ok("H1 useContentSize true", /useContentSize:\s*true/.test(mainJs));
  ok("H1 transparent: true", /transparent:\s*true/.test(mainJs));
  ok("H1 no OS shadow (design paints its own)", /hasShadow:\s*false/.test(mainJs));
  ok("H1 fully transparent background color", /backgroundColor:\s*"#00000000"/.test(mainJs));
  ok("H1 fixed-size window (resizable/maximizable/fullscreenable off)",
    /resizable:\s*false/.test(mainJs) && /maximizable:\s*false/.test(mainJs) && /fullscreenable:\s*false/.test(mainJs));
  const html = fs.readFileSync(path.join(SETUP, "index.html"), "utf8");
  ok("H1 renderer body background transparent", /background:\s*transparent/.test(html));
  ok("H1 fake desktop backdrop hidden (no smeared edges)", /\.desktop\{[^}]*display:\s*none/.test(html));
  ok("H1 design canvas still 900×640 (untouched)", /\.window\{[^}]*width:\s*900px;\s*height:\s*640px/.test(html.replace(/\n/g, "")));
}

/* ================= H2 — staging rescue (the ENOENT fix) ================= */
console.log("\nH2 — payload staging rescue (portable RMDir race)");
{
  const mainJs = fs.readFileSync(path.join(SETUP, "dist-electron", "main.js"), "utf8");
  ok("H2 staging module compiled in", mainJs.includes("startPayloadStaging") && mainJs.includes("copyTreeTolerant"));
  ok("H2 staging lives under MementoSetup/staging (private dir)",
    mainJs.includes("MementoSetup") && mainJs.includes("staging"));
  ok("H2 stale stage-* cleanup on boot", mainJs.includes("cleanupStaleStaging"));
  ok("H2 install reads the STAGED payload (installPayloadDir)", mainJs.includes("installPayloadDir()"));
  ok("H2 setup:start awaits the staging promise before installing",
    /staging\?\.promise/.test(mainJs));
  ok("H2 staging disposed on quit", mainJs.includes("disposeStaging"));
  ok("H2 staging only when packaged (dev runs unchanged)", /isPackaged\)\s*return/.test(mainJs));
}

/* ============ H3 — tolerant installerCore (LIVE behavioral) ============ */
console.log("\nH3 — tolerant installer: vanished/locked files skip, install completes");
{
  const core = fs.readFileSync(path.join(SETUP, "dist-electron", "installerCore.js"), "utf8");
  ok("H3 tolerance compiled in (skipped counter)", core.includes("skipped"));
  ok("H3 antivirus guidance in the payload-missing message",
    /antivirus/i.test(core) && /payload is missing/.test(core));
  ok("H3 Update Center hint on skipped payload files", /Update Center/.test(core));
  ok("H3 honest missing-core warning", /was NOT installed/.test(core));

  // LIVE: full-tree install where one payload file is UNREADABLE (EACCES)
  const work = fs.mkdtempSync(path.join(os.tmpdir(), "taskH-tolerant-"));
  const payloadDir = path.join(work, "payload");
  fs.mkdirSync(path.join(payloadDir, "sub"), { recursive: true });
  fs.writeFileSync(path.join(payloadDir, "a.txt"), "A".repeat(4096));
  fs.writeFileSync(path.join(payloadDir, "sub", "b.txt"), "B".repeat(4096));
  const locked = path.join(payloadDir, "locked.bin");
  fs.writeFileSync(locked, "LOCKED".repeat(2048));
  fs.chmodSync(locked, 0o000); // non-root owner can no longer read it

  const dest = path.join(work, "dest");
  const mod = await import(path.join(SETUP, "dist-electron", "installerCore.js"));
  const events = [];
  const result = await mod.runInstall(
    { destDir: dest, createDesktopShortcut: false },
    {
      isWin: false,
      appVersion: "3.1.7",
      payloadDir,
      coreVersions: {},
      desktopDir: () => path.join(work, "desktop"),
      startMenuDir: () => path.join(work, "sm"),
      writeShortcut: () => "skipped",
      writeUninstallRegistration: () => {},
      removeUninstallRegistration: () => {},
      closeRunningApp: () => false,
      onEvent: (ev) => events.push(ev),
      cancelled: () => false,
    }
  );
  ok("H3 install SUCCEEDS despite an unreadable payload file", result.ok === true, result.error || "");
  ok("H3 the unreadable file was skipped and reported",
    events.some((e) => e.type === "log" && /skipped/.test(e.line || "")));
  ok("H3 all readable files still landed", fs.existsSync(path.join(dest, "a.txt")) && fs.existsSync(path.join(dest, "sub", "b.txt")));
  ok("H3 skipped file honestly absent from destination", !fs.existsSync(path.join(dest, "locked.bin")));
  const errEvents = events.filter((e) => e.type === "error");
  ok("H3 no hard error event for a tolerated skip", errEvents.length === 0, JSON.stringify(errEvents).slice(0, 120));
  fs.chmodSync(locked, 0o644);
  fs.rmSync(work, { recursive: true, force: true });
}

/* ================= H4 — MHRV overhaul (LIVE module drive) ================= */
console.log("\nH4 — MHRV: domains, multi deployment IDs, mhrv-rs settings, logs");
{
  const work = path.join(ROOT, "taskH-smoke-tmp");
  fs.rmSync(work, { recursive: true, force: true });
  fs.mkdirSync(work, { recursive: true });
  (globalThis).__STUB_USERDATA = work;
  fs.writeFileSync(
    path.join(work, "taskH4-entry.ts"),
    `export * from "${path.join(APP, "electron", "mhrv.ts").replace(/\\/g, "/")}";\n`
  );
  const bund = spawnSync("npx", [
    "esbuild", path.join(work, "taskH4-entry.ts"), "--bundle", "--platform=node",
    `--alias:electron=${path.join(HERE, "taskF-electron-stub.mts")}`,
    `--outfile=${path.join(work, "taskH4-entry.cjs")}`,
  ], { encoding: "utf8", cwd: ROOT, timeout: 120000 });
  ok("H4 mhrv.ts bundles under the electron stub", fs.existsSync(path.join(work, "taskH4-entry.cjs")), (bund.stderr || "").slice(-160));
  if (fs.existsSync(path.join(work, "taskH4-entry.cjs"))) {
    const m = await import(path.join(work, "taskH4-entry.cjs"));
    ok("H4 managed front domains ship a mhrv-like list (>=16)", (m.DEFAULT_FRONT_DOMAINS || []).length >= 16, String((m.DEFAULT_FRONT_DOMAINS || []).length));
    ok("H4 default www.google.com member of the managed list", (m.DEFAULT_FRONT_DOMAINS || []).includes("www.google.com"));
    ok("H4 SNI pool has the mhrv 13 candidates", (m.DEFAULT_SNI_POOL || []).length === 13, String((m.DEFAULT_SNI_POOL || []).length));

    // config sanitize — REAL saveConfig through the stub userData
    const saved = m.saveConfig({
      scriptIds: ["  AKfycbID-1 ", "", "AKfycbID-2", 42],
      frontDomains: ["www.google.com", " not-google.example ", "www.google.com"],
      sniPool: ["keep"],
      logLevel: "bogus",
      parallelDispatch: 9999,
      upstreamSocks5: " 127.0.0.1:50529 ",
      shareLan: true,
      blockQuic: true,
      blockStun: true,
      youtubeThroughRelay: true,
      normalizeXTwitter: true,
    });
    ok("H4 multi deployment IDs saved as a clean array", Array.isArray(saved.scriptIds) && saved.scriptIds[0] === "AKfycbID-1" && saved.scriptIds.includes("AKfycbID-2"), JSON.stringify(saved.scriptIds));
    ok("H4 frontDomains sanitized (trim, dedupe, active domain kept)",
      saved.frontDomains.includes("www.google.com") && saved.frontDomains.includes("not-google.example") &&
      saved.frontDomains.filter((d) => d === "www.google.com").length === 1, JSON.stringify(saved.frontDomains));
    ok("H4 bogus logLevel falls back to info", saved.logLevel === "info");
    ok("H4 parallelDispatch clamped to sane bounds", saved.parallelDispatch >= 0 && saved.parallelDispatch <= 64, String(saved.parallelDispatch));
    ok("H4 upstream socks5 trimmed + parsed", saved.upstreamSocks5 === "127.0.0.1:50529" && m.parseUpstreamSocks5(saved.upstreamSocks5)?.host === "127.0.0.1");
    ok("H4 invalid upstream parses to null (honest fallback)", m.parseUpstreamSocks5("no-port-here") === null);
    ok("H4 shareLan persisted", saved.shareLan === true);
    const reloaded = m.loadConfig();
    ok("H4 config persists across loads (config.json)", reloaded.scriptIds?.[0] === "AKfycbID-1" && reloaded.frontDomains?.length >= 2);

    // log ring buffer — level filtering + cap
    m.mhrvLogsClear();
    m.mlog("error", "E-line");
    m.mlog("info", "I-line");
    m.mlog("debug", "D-line");
    const all = m.mhrvLogsGet({ limit: 50 });
    ok("H4 log ring captures levels", all.some((l) => l.text === "E-line") && all.some((l) => l.text === "I-line"));
    ok("H4 min-level filter excludes debug at info", !m.mhrvLogsGet({ level: "info", limit: 50 }).some((l) => l.text === "D-line"));
    ok("H4 error filter returns only error+ lines", m.mhrvLogsGet({ level: "error", limit: 50 }).every((l) => l.level === "error"));

    // host matching — the two relay routing toggles are REAL functions
    ok("H4 youtubeThroughRelay routes googlevideo/youtube hosts", m.matchesYoutubeRelay("rr3---sn-abcd.googlevideo.com") === true && m.matchesYoutubeRelay("example.com") === false);
    ok("H4 SNI rewrite matcher still Google-only", m.matchesSniRewrite("www.google.com") === true && m.matchesSniRewrite("example.com") === false);

    // round-robin failover is exported and shaped correctly
    ok("H4 relayWithFailover exported (multi-ID auto-failover)", typeof m.relayWithFailover === "function");
    ok("H4 socks5Connect exported (upstream chaining)", typeof m.socks5Connect === "function");
  }

  // renderer static gates — the mhrv-rs settings surface really exists
  const gst = fs.readFileSync(path.join(ROOT, "src", "components", "GoogleSideTab.tsx"), "utf8");
  ok("H4 UI: multiline Deployment IDs (round-robin tip)", /one deployment ID per line|round-robin/i.test(gst));
  ok("H4 UI: front-domain chip manager (select + add + remove)",
    /frontDomains/.test(gst) && /frontDomain/.test(gst));
  ok("H4 UI: Share with other devices toggle", /shareLan|Share with other devices/i.test(gst));
  ok("H4 UI: Upstream SOCKS5 + Parallel dispatch + Log level", /upstreamSocks5/.test(gst) && /parallelDispatch/.test(gst) && /logLevel/.test(gst));
  ok("H4 UI: QUIC + STUN/TURN blocks", /blockQuic/.test(gst) && /blockStun/.test(gst));
  ok("H4 UI: X/Twitter normalize + YouTube relay toggles", /normalizeXTwitter/.test(gst) && /youtubeThroughRelay/.test(gst));
  ok("H4 UI: Save config + CA remove/check + check updates", /mhrv_ca_remove/.test(gst) && /mhrv_ca_check/.test(gst) && /mhrv_update_check/.test(gst));
  ok("H4 UI: recent log console (get/clear/save)", /mhrv_logs_get/.test(gst) && /mhrv_logs_clear/.test(gst) && /mhrv_logs_save/.test(gst));
  const ipc = fs.readFileSync(path.join(APP, "electron", "ipc.ts"), "utf8");
  ok("H4 IPC: all six new handlers registered",
    ["mhrv_logs_get", "mhrv_logs_clear", "mhrv_logs_save", "mhrv_ca_remove", "mhrv_ca_check", "mhrv_update_check"]
      .every((c) => ipc.includes(`"${c}"`)));
  const pre = fs.readFileSync(path.join(APP, "electron", "preload.ts"), "utf8");
  ok("H4 preload allowlist extended", ["mhrv_logs_get", "mhrv_ca_remove", "mhrv_ca_check", "mhrv_update_check"].every((c) => pre.includes(`"${c}"`)));
}

/* ============ H5 — Live Connection per-app consumption ============ */
console.log("\nH5 — Live Connection: per-app bytes, rates, details");
{
  const cs = fs.readFileSync(path.join(APP, "dist-electron", "connectionStats.js"), "utf8");
  ok("H5 sing-box rows carry sourceIP/sourcePort (attribution join key)", /sourceIP/.test(cs) && /sourcePort/.test(cs));
  const tab = fs.readFileSync(path.join(ROOT, "src", "components", "LiveConnTab.tsx"), "utf8");
  ok("H5 renderer joins snapshot ports with core rows", tab.includes("sourcePort") && tab.includes("live_conn_snapshot") && tab.includes("get_connection_stats"));
  ok("H5 per-app byte ledger with reset-safe deltas", /delta|prev/i.test(tab) && /ledger|Map</.test(tab));
  ok("H5 live speed EMA", /EMA|ema|0\.45|alpha/i.test(tab));
  ok("H5 honest xray granularity note (no per-app split)", /per-outbound|xray/i.test(tab));
  ok("H5 top-consumer highlight + usage share bars", /top consumer|crown/i.test(tab));
  ok("H5 byte formatter (B/KB/MB/GB)", /formatBytes|fmtBytes/i.test(tab));
  const mock = fs.readFileSync(path.join(ROOT, "src", "electron-mock.ts"), "utf8");
  ok("H5 browser-preview mock for connection stats", mock.includes("get_connection_stats"));
  // LIVE: the OS snapshot still parses on this host (Linux ss path)
  const lc = await import(path.join(APP, "dist-electron", "liveConn.js"));
  const snap = lc.liveConnSnapshot();
  ok("H5 LIVE snapshot returns honest rows on this host", Array.isArray(snap.rows) && Array.isArray(snap.apps) && snap.totals && typeof snap.totals.apps === "number", `rows=${snap.rows?.length}`);
  ok("H5 LIVE aggregateByApp keeps per-app counts (no bytes invented)", snap.apps.every((a) => typeof a.total === "number" && (a.download === undefined || typeof a.download === "number")));
}

/* ============ H6 — Config Builder (v2rayN-style) ============ */
console.log("\nH6 — Import Config: Config Builder");
{
  const p = path.join(ROOT, "src", "components", "ConfigBuilderTab.tsx");
  ok("H6 ConfigBuilderTab exists", fs.existsSync(p));
  const src = fs.readFileSync(p, "utf8");
  ok("H6 generates all four share-link schemes", ["vmess://", "vless://", "trojan://", "ss://"].every((s) => src.includes(`"${s}"`) || src.includes(`'${s}'`) || src.includes(s + "`") || new RegExp(s.replace("://", "://")).test(src)));
  ok("H6 transport coverage tcp/ws/grpc/h2", /grpc/.test(src) && /httpupgrade|ws/.test(src));
  ok("H6 Reality support (pbk/sid/fp)", /pbk/.test(src) && /sid/.test(src) && /fp/.test(src));
  ok("H6 QR code preview", /qrcode/i.test(src));
  ok("H6 imports through the REAL store path (addConfigs)", /addConfigs/.test(src) || /onImported/.test(src));
  const imp = fs.readFileSync(path.join(ROOT, "src", "components", "ImportTab.tsx"), "utf8");
  ok("H6 integrated into ImportTab behind a segmented mode", imp.includes("ConfigBuilderTab") && /builder/.test(imp));
  const es = spawnSync("npx", ["esbuild", p, "--loader:.tsx=tsx", "--bundle=false"], { encoding: "utf8", cwd: ROOT, timeout: 60000 });
  ok("H6 builder parses cleanly", es.status === 0, (es.stderr || "").slice(-120));
  // REAL parser accepts a builder-shaped REALITY vless link (the exact format H-b verified)
  const store = fs.readFileSync(path.join(ROOT, "src", "store.ts"), "utf8");
  ok("H6 real store parser present (parseSingleLink)", store.includes("export function parseSingleLink"));
}

/* ============ H7 — real Windows artifacts 3.1.7 ============ */
console.log("\nH7 — Windows artifacts for the 3.1.7 round");
{
  const exeApp = path.join(APP, "release", "MEMENTO-3.1.7.exe");
  const exeSetup = path.join(SETUP, "release", "MementoSetup-2.0.2.exe");
  ok("H7 MEMENTO-3.1.7.exe exists", fs.existsSync(exeApp));
  ok("H7 MementoSetup-2.0.2.exe exists", fs.existsSync(exeSetup));
  if (fs.existsSync(exeSetup)) {
    const seven = path.join(ROOT, "node_modules", "7zip-bin", "linux", "x64", "7za");
    const tmp = path.join(os.tmpdir(), "taskH-sfx.7z");
    const buf = fs.readFileSync(exeSetup);
    const i = buf.indexOf(Buffer.from([0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]));
    fs.writeFileSync(tmp, i >= 0 ? buf.subarray(i) : buf);
    const t = spawnSync(seven, ["t", tmp], { encoding: "utf8", timeout: 240000 });
    ok("H7 setup SFX archive integrity (7za t)", t.status === 0, (t.stderr || "").slice(-120));
  }
  const meta = JSON.parse(fs.readFileSync(path.join(SETUP, "payload-meta.json"), "utf8"));
  ok("H7 payload-meta declares appVersion 3.1.7 + runtime-reuse", meta.appVersion === "3.1.7" && meta.mode === "runtime-reuse");
}

console.log("\n========================================");
console.log(`taskH smoke: ${pass} passed, ${fail} failed`);
console.log("========================================");
process.exit(fail > 0 ? 1 : 0);
