# MEMENTO 3.1.7 — build notes

## The four changes of this round

1. **MementoSetup installs again + design-exact window**
   - ROOT CAUSE of the user's `Installation failed: ENOENT …\Temp\<id>\resources\payload`:
     the setup ships as an electron-builder **portable** SFX. Every launch of the
     SAME exe extracts to the SAME `%TEMP%\<unpack-id>` folder and a NEW launch
     begins with `RMDir /r` on that exact folder (portable.nsi line 38). Users
     double-click → the second stub wipes the payload + loose data files out from
     under the RUNNING wizard (running exe/DLLs survive — Windows locks open
     images — data files do not).
   - FIX (setup-app/electron/main.ts): seconds after launch the payload is
     **staged** into a private `%LOCALAPPDATA%\MementoSetup\staging\stage-<pid>-<ts>`
     folder and the install reads from THERE (`installPayloadDir()`); stale stage
     folders are cleaned on boot; the stage is disposed on quit.
   - FIX (setup-app/electron/installerCore.ts): the installer is now TOLERANT —
     vanished/locked files are skipped with honest log lines and the install
     COMPLETES; skipped payload files produce a visible warning pointing at
     Update Center; missing cores after install are reported honestly; the
     payload-missing message now explains the antivirus / double-launch cause.
   - Window: the Electron frame is now **transparent** with the 900×640 design
     canvas at exact 1:1 scale (960×730 content incl. shadow margin), fixed size —
     the rounded corners ARE the window shape; no square corners sticking out.

2. **Import Config → Config Builder (v2rayN-style generator)**
   - New `src/components/ConfigBuilderTab.tsx` behind a segmented mode in
     ImportTab (Quick Import / Config Builder). Protocols VMess / VLESS (Reality,
     Vision) / Trojan / Shadowsocks (SIP002 + plugins), transports tcp/ws/grpc/h2/
     httpupgrade, TLS block (sni/alpn/fp/allowInsecure), step rail with auto
     checks, live terminal link preview + JSON view + inline QR (qrcode dep),
     UUID/password generators, validation-gated Add-to-MEMENTO through the real
     `addConfigs()` path. Fully bilingual (EN/FA) + RTL.

3. **MHRV (GOOGLE SIDE) overhaul — mirrors mhrv-rs v1.9.37**
   - Front-domain MANAGER (selectable chip list + add/remove, active chip =
     frontDomain), SNI pool chip with probe, **multi Deployment IDs** textarea
     (one per line) with real round-robin auto-failover (`relayWithFailover`),
     Auth key with show toggle, Mode select (Apps Script (MTM) / Direct),
     Google IP + scan IPs, Share-with-other-devices (binds 0.0.0.0), HTTP/SOCKS
     ports, Advanced: Upstream SOCKS5 (real SOCKS5 client chaining), Parallel
     dispatch, Log level, Verify TLS, Normalize X/Twitter GraphQL, YouTube through
     relay, Block QUIC (UDP/443), Block STUN/TURN; Save config (config path
   shown), Install/Remove/Check CA, Check for updates, and a Recent log console
     (500-line ring buffer, level filter, show/save/clear) — new IPC:
     mhrv_logs_get/clear/save, mhrv_ca_remove/check, mhrv_update_check.

4. **Live Connection = per-app consumption**
   - sing-box clash_api rows now carry `metadata.sourceIP/sourcePort`
     (connectionStats.ts) and LiveConnTab joins them to the OS socket snapshot
     (netstat/tasklist) → per-app byte ledger with reset-safe deltas, EMA live
     speeds, session totals, usage share bars, top-consumer highlight, per-app
     drill-down (sockets + proxied connections + remote targets). xray is shown
     honestly at tunnel level (its stats API has no per-connection counters).

## Version bump
- root + electron-app: **3.1.7** · setup-app: **2.0.2** · Update Center fallback: 3.1.7

## Build pipeline (Windows x64, cross-built on Linux)
```
cd electron-app  && ELECTRON_BUILDER_COMPRESSION_LEVEL=7 npm run dist     # MEMENTO-3.1.7.exe
cd setup-app     && ELECTRON_BUILDER_COMPRESSION_LEVEL=7 npm run dist     # MementoSetup-2.0.3.exe (predist runs sync-payload)
```
- `ELECTRON_BUILDER_COMPRESSION_LEVEL=7` is REQUIRED (the default mx=9 7z pass
  OOMs a 4 GB sandbox).
- Icons are embedded natively by electron-builder (`signExecutable: false`,
  no wine); verify with `node scripts/check-icon.mjs <exe> <icon.ico>`.
- Gates: `scripts/taskH-smoke.mjs` (77+), `scripts/taskG-smoke.mjs` (69),
  `scripts/taskF-smoke.mjs` (91) — all green on the shipped artifacts.
- Deliver: `node scripts/taskH-zip.mjs` → `download/MEMENTO-3.1.7/`.

## AV-hardening round (setup 2.0.3, MEMENTO stays 3.1.7)

FIELD REPORT being addressed: real-Windows installs report "files were
removed by the antivirus" even with third-party AV disabled (Windows
Defender stays active). The installer's own pattern was the problem:
an unsigned portable SFX that extracts to `%TEMP%`, byte-copies its OWN
running exe (`process.execPath → MEMENTO.exe`) and re-writes every
unsigned proxy core through a staging location — a textbook dropper
signature for Defender's heuristics. Evidence chain in
`setup-app/electron/installerCore.ts` header; user-facing contract in
`setup-app/README.md` (EN+FA); manual Windows legs in
`electron-app/TESTING-CHECKLIST.md` §36.

The four changes:
1. **requireAdministrator** (user request): `portable.requestedExecutionLevel`
   in setup-app/electron-builder.yml — UAC on every launch. Honest note:
   elevation does not whitelist anything; it is the explicit ask, and the
   per-user install/HKCU/uninstall contract is unchanged. `setup:launch`
   spawns MEMENTO through explorer.exe so it never inherits the admin token.
2. **Hardlink instead of self-copy** (installerCore 4a): `fs.linkSync` first
   (zero bytes of the running image re-written), plain copy only as the
   cross-volume fallback.
3. **Move-staging** (main.ts): the payload is RENAMED out of the SFX
   extraction folder (metadata op, no third content write of the cores);
   tolerant byte copy stays as the EXDEV/locked fallback. All 2.0.2
   guarantees keep (stale sweep, single instance, dispose on quit).
4. **Honest guidance**: always-visible completion log line about the
   unsigned binaries + exact Windows Security steps; the setup NEVER
   touches AV settings itself.

Version bump: setup-app **2.0.3** (main.ts SETUP_VERSION + package.json) ·
MEMENTO stays **3.1.7** · taskH-smoke/taskH-zip updated to the 2.0.3 name.

## Field report #2 round (setup 2.0.4, MEMENTO stays 3.1.7)

FIELD REPORT being addressed: on a real Windows 11 machine, setup 2.0.3
reached 100% with an error line — and the installed app would not launch.
Screenshots of `C:\Game` confirmed the exact mechanism: the runtime-reuse
clone worked (MEMENTO.exe = the setup image, 246,366,208 bytes,
locales/en-US.pak, all DLLs present; icons + cores folder landed), but
`resources\app.asar` was MISSING. Windows Defender removed the app's code
mid-install; the tolerant copy (right for the cores, WRONG for the app
code) skipped it and still reported success. Without
`resources\app.asar`, Electron exits with
`Cannot find module ...resources\app.asar` — hence "اجرا نمیشه".

The 2.0.4 fix (setup-app/electron/installerCore.ts):
1. **Contract gate (pre-copy)**: runtime-reuse payloads must contain a
   readable `resources/app.asar` — a payload quarantined BEFORE the copy
   aborts before writing anything (a manifest-driven check alone would
   never notice a file the AV removed that early).
2. **Verify + heal (post-copy)**: every file is checked against its
   source size; transient AV scan-locks are re-copied automatically
   (3 rounds). The log ends with the receipt:
   `verified N/N installed files against the payload manifest`.
3. **Hard gate**: a still-missing `app.asar`/`MEMENTO.exe` FAILS the
   install — the wizard shows the error row (Retry / back to
   destination) with the file name and the Protection-history steps.
4. **Leave no trace**: a failed fresh install removes its partial
   destination; a failed upgrade restores the previous install
   byte-for-byte (previously only true when a backup existed).

Gates: `scripts/taskH-smoke.mjs` gained H9 (LIVE: contract gate ×2,
hard-gate abort + rollback restoring the previous install, honest
non-critical miss with the verified summary, leave-no-trace, happy
path). taskG-G8/G10 + taskH-H7/H8 + taskH-zip updated to the 2.0.4
artifact name. Docs: setup-app/README.md "Field report #2" (EN+FA) +
TESTING-CHECKLIST §37.

Version bump: setup-app **2.0.4** · MEMENTO stays **3.1.7** (the app
artifact itself is unchanged — same build, same SHA-256).

HONEST LIMIT (unchanged): this sandbox has no Windows. The 2.0.4
mechanisms are LIVE-tested on Linux through the ELECTRON-FREE pipeline;
the real-machine legs in TESTING-CHECKLIST §37 (quarantine behavior,
UAC, launch after repair) still need the affected machine.

---

## Field report #3 — setup 2.0.5 (the unpacked app payload round)

**Field evidence (screenshot, same real Windows 11 machine):** setup
2.0.4 aborted at 1% with the contract-gate message —
`✓ initializing installer context` → `✗ the app code (resources/app.asar)
is missing from the installer payload … Nothing was installed`, both lines
in the same second. The 2.0.4 hard gate worked exactly as designed
(2.0.3 would have "succeeded" into a broken install), and Defender's
quarantine of the single 4.1 MB app.asar was caught before any file was
written.

**Forensics:** the wizard's own asar survived every run while the app's
asar died — a content-based verdict. The app asar carried the MHRV
engine's literals (`certutil -user -addstore Root`, PowerShell UAC
relaunch, `netsh`); Defender scans inside asar archives. Forensic greps of
the shipped asars found no exclusion-command literals (no
`Add-MpPreference` anywhere in payload or wizard) — the H8 contract held.

**Changes (setup 2.0.5):**
1. `electron-app/electron-builder.yml`: `asar: false` — the app ships as
   a plain `resources/app/` tree (~114 files). No asar blob to kill
   wholesale; a per-file quarantine is heal-able by the 2.0.4 verify pass.
2. `setup-app/scripts/sync-payload.js`: payload copies
   `resources/app/` (tree) instead of `app.asar`.
3. `setup-app/electron/installerCore.ts`:
   `CRITICAL_PAYLOAD_FILES = [resources/app/package.json,
   resources/app/dist-electron/main.js]`; the contract gate loops and
   names every missing critical file.
4. `setup-app/electron/main.ts` + `preload.ts` + `src/setup.ts`: new
   error-row buttons — "Copy paths for exclusions" (clipboard, main
   process) and "Open Windows Security" (`ms-settings:windowsdefender`).
   The setup still never modifies AV settings itself.
5. Version → 2.0.5 (setup-app package.json + SETUP_VERSION). App version
   stays 3.1.7 (the app code is unchanged — only its packaging format).

**Honest limit:** no Windows/Defender in this sandbox — whether the
unpacked layout ends the quarantine is provable only per
TESTING-CHECKLIST §38 on a real machine. Code signing remains the only
complete fix (user budget decision).

## Setup 2.0.6 — the window IS the panel (cosmetic round)

Field feedback on 2.0.5 (which installed + launched fine): the wizard
rendered inside a transparent 960×730 canvas (900×640 panel centered +
CSS drop-shadow) and real desktops read that as a dark margin/halo
around the window. 2.0.6, purely cosmetic, SETUP ONLY:

1. `setup-app/electron/main.ts`: the window IS the panel — width:900
   height:640, `transparent:false`, `roundedCorners:false`,
   `hasShadow:true` (native OS shadow only), opaque
   `backgroundColor:"#070c09"` (the design gradient's darkest tone).
2. `setup-app/index.html`: `.window` = 100vw/100vh, border-radius 0,
   outer box-shadow layers removed (inset lighting only), `.stage-hint`
   removed. design-head.html stays a non-built reference on purpose.
3. `setup-app/src/setup.ts`: `fitStage` scale is 1:1 (the viewport IS
   the 900×640 panel; shrink remains only as an emergency fallback).
4. setup-app package.json + SETUP_VERSION → 2.0.6. electron-app is
   UNTOUCHED — MEMENTO-3.1.7.exe stays byte-identical to the R3 seal.

Install pipeline, payload and gates are unchanged (gate version refs
bumped; one new H10 window-options gate).

### Field report #4 — setup 2.0.7 / app 3.1.8 (in-place destination round)

Field evidence: `✗ cannot stage destination (EPERM: operation not
permitted, rename 'C:\Users\…\Downloads' -> '…\Downloads.bak-…')` — the
destination stage-aside renamed the ENTIRE destination, which is only
valid for folders MEMENTO owns. Fix: sentinel-based ownership rule (only
a previous MEMENTO install is staged aside; foreign folders are installed
into in place), honest EPERM message for locked owned installs,
manifest-driven leave-no-trace for failed in-place runs, ownership
sentinel upgraded (inPlace + exact file list, always written, merge-safe
with the ARP twin), and the matching app-side uninstall contract (3.1.8):
in-place installs uninstall file-exactly from the recorded manifest —
never `rmdir /s /q` on a folder containing user data. App version bumps
3.1.7 → 3.1.8 because the APP code changed (uninstall.ts + main.ts
runner); setup bumps 2.0.6 → 2.0.7.
